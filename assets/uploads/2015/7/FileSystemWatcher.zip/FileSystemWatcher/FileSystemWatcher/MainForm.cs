﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileSystemWatcherTest
{
    public partial class MainForm : Form
    {
        private FileSystemWatcher _watcher;

        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _watcher = new FileSystemWatcher();
                _watcher.Path = dlg.SelectedPath;
                _watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName;
                _watcher.Filter = "*.*";

                //Add event handlers
                _watcher.Changed += new FileSystemEventHandler(OnChanged);
                _watcher.Created += new FileSystemEventHandler(OnChanged);
                _watcher.Deleted += new FileSystemEventHandler(OnChanged);
                _watcher.Renamed += new RenamedEventHandler(OnRenamed);

                lblWatchedPath.Text = dlg.SelectedPath;
                _watcher.EnableRaisingEvents = true;
            }
        }

        private void OnRenamed(object sender, RenamedEventArgs e)
        {           
            AddEvent(e);          
        }

        private void OnChanged(object source, FileSystemEventArgs e)
        {            
            AddEvent(e);
        }

        private void AddEvent(FileSystemEventArgs e)
        {
            ListViewItem item = new ListViewItem();
            item.Text = e.FullPath;
            item.SubItems.Add(e.ChangeType.ToString());
            item.Tag = e;

            AddItemDelegate dg = new AddItemDelegate(AddItem);
            listEvents.Invoke(dg, item);            
        }

        private delegate void AddItemDelegate(ListViewItem item);

        private void AddItem(ListViewItem item)
        {
            listEvents.Items.Insert(0, item);
        }

        private void listEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDetail.Text = "";

            if (listEvents.SelectedItems.Count == 0)
                return;

            ListViewItem selectedItem = listEvents.SelectedItems[0];
            if (selectedItem != null)
            {
                if (selectedItem.Tag is RenamedEventArgs)
                {
                    RenamedEventArgs arg = (selectedItem.Tag as RenamedEventArgs);
                    txtDetail.Text = "Renamed file : " + arg.OldFullPath + Environment.NewLine + "to: " + arg.FullPath;
                }
            }
        }
    }
}

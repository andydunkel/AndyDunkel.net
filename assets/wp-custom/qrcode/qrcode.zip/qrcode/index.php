<html>
	<head>
		<title>Example for dynamic QR code creation</title>
		
		<style type="text/css">
		<!--
		body { background-color:#FFFFFF;  }
		h1 { color:#000000; font-family:Arial,Helvetica,Geneva; font-size:12pt; }
		p,li { color:#000080; font-family:Arial,Helvetica,Geneva; font-size:10pt; }
		-->
</style>

	</head>
	<body>
		<h1>Example for dynamic QR code creation</h1>
		<img src="img.php">
	</body>
</html>
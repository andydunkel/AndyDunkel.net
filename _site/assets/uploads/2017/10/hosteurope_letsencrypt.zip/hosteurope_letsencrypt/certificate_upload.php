<?php
/*
include file must contain
$accountname = 'NAME VON HOSTEUROPE ACCOUNT';
$password = 'KIS-PASSWORT';
$accountnummer = 'NUMMER VON HOSTEUROPE ACCOUNT';
$myemail = 'EMAILADRESSE FUER BESTAETIGUNG';

Nur die n�chste Zeile muss ge�ndert werden
*/
$homedir = '/is/htdocs/wp999999_ZZZZZZZZZ';
include("$homedir/.kis");

$url[0] = 'https://kis.hosteurope.de/?logout=1';
$url[1] = 'https://kis.hosteurope.de/index.php';
$post[1] = array(
'is_fl'=>1,
'kdnummer'=>$accountname,
'lang'=>'de',
'login_type'=>'',
'passwd'=>$password,
);
$url[2] = 'https://kis.hosteurope.de/administration/webhosting/admin.php';
$post[2] = array(
    "v_id"=>"0",
    "menu"=>"6",
    "mode"=>"sslupload",
    "wp_id"=>$accountnummer,
    "submode"=>"sslfileupload",
);
if(function_exists('curl_file_create')) {
    $post[2]['certfile'] = curl_file_create(__DIR__ . '/fullchain.pem'); 
    $post[2]['keyfile'] = curl_file_create(__DIR__ . '/domain_key.pem'); 
} 
else {
    $post[2]['certfile'] = '@' . __DIR__ . '/fullchain.pem'; 
    $post[2]['keyfile'] = '@' . __DIR__ . '/domain_key.pem'; 
}


foreach($url as $i=>$u) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_VERBOSE, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
    curl_setopt($ch, CURLOPT_URL, $u);
var_dump($u);
    curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookies.txt'); # writes Cookies
    if($i > 0) {
        curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt'); # reads cookies
    }
    if(isset($post[$i])) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post[$i]); 
#var_dump($post[$i]);
    }
    $response = curl_exec($ch);
    
    #echo $response . "<HR><HR>\n\n";
    #file_put_contents("certificate_output_$i.html", $response);
    $strings = array('Willkommen in Ihrem Kunden-Informations-System (KIS)', 'Die Dateien wurden erfolgreich hochgeladen');
    foreach($strings as $s) {
        if(substr_count($response, $s) > 0) {
            echo "$s\n";
            $mailMessage .= "$s\n";
        }
    }
}

mail($myemail, "Let's Encrypt installiert", $mailMessage);

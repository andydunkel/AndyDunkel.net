#!/bin/sh

/usr/bin/env php7.0 CertLE.php cert account_key.pem domain_key.pem \
	-w /is/htdocs/wp999999_ZZZZZZZZ/www/DOMAIN1/ \
	-d www.domain1.com \
	-w /is/htdocs/wp999999_ZZZZZZZZ/www/DOMAIN2/ \
	-d www.domain2.com \
	--csr csr.pem \
	--cert cert.pem \
	--chain chain.pem \
	--fullchain fullchain.pem

#!/bin/sh

/usr/bin/env php7.0 certificate_upload.php

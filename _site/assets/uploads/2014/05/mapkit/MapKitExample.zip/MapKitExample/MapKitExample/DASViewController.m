//
//  DASViewController.m
//  MapKitExample
//
//  Created by Andy on 04/05/14.
//  Copyright (c) 2014 Andy Dunkel. All rights reserved.
//

#import "DASViewController.h"

@interface DASViewController ()
- (IBAction)setType:(UISegmentedControl *)sender;

@end

@implementation DASViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.mapView.delegate = self;
    
    // Create your coordinate
    CLLocationCoordinate2D myCoordinate = {47.879854, 10.641000};
    
    //Create your annotation
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    // Set your annotation to point at your coordinate
    point.coordinate = myCoordinate;
    point.title = @"Andys Home";
    
    //Drop pin on map
    [self.mapView addAnnotation:point];
    
    //set location and zoom level
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(myCoordinate, 1000, 1000);
    MKCoordinateRegion adjustedRegion = [self.mapView regionThatFits:viewRegion];
    [self.mapView setRegion:adjustedRegion animated:YES];
    

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)setType:(UISegmentedControl *)sender {
    switch (sender.selectedSegmentIndex) {
        case 0:
            self.mapView.mapType = MKMapTypeStandard;
            break;
        case 1:
            self.mapView.mapType = MKMapTypeSatellite;
            break;
        case 2:
            self.mapView.mapType = MKMapTypeHybrid;
            break;
        default:
            break;
    }
}

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation {
    
    CLLocationCoordinate2D myCoordinate = {47.879854, 10.641000};
    CLLocationCoordinate2D userCoordinate = [[[self.mapView userLocation]
                                              location] coordinate];
    
    CLLocation *myLoc = [[CLLocation alloc] initWithLatitude:myCoordinate.latitude
                                                   longitude:myCoordinate.longitude];
    CLLocation *userLoc = [[CLLocation alloc] initWithLatitude:userCoordinate.latitude
                                                     longitude:userCoordinate.longitude];
    
    CLLocationDistance distance = [myLoc distanceFromLocation:userLoc];
    
    NSString *labelText = [NSString stringWithFormat:@"%lf km", distance / 1000];
    
    [self.labelPosition setText:labelText];
}
    
@end

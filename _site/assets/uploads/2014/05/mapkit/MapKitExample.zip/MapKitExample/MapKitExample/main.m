//
//  main.m
//  MapKitExample
//
//  Created by Andy on 04/05/14.
//  Copyright (c) 2014 Andy Dunkel. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DASAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DASAppDelegate class]));
    }
}

package com.da.perspectives.contributiongui;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.ResourceManager;

public class ImageView extends ViewPart {
	
	public final static String ID = "com.da.perspectives.contributiongui.imageview";
	
	public ImageView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		
		Label lblNewLabel = new Label(parent, SWT.NONE);
		lblNewLabel.setImage(ResourceManager.getPluginImage("com.da.perspectives.contributiongui", "res/image.png"));
		// TODO Auto-generated method stub

	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

}
